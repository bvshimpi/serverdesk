var path = require("path");
var db = require("../dbConnector");
var errorMsg = require("../../utils/errorMessages");
var responseGenerator = require("../../utils/responseGenerator");

exports.login = function(req, res) {
    var email = typeof req.body.email != "undefined" ? req.body.email : "";
    var password = typeof req.body.password != "undefined" ? req.body.password : "";
    if(email != "" && password != ""){
        var values = [email, password];
        res.send(responseGenerator.getResponse(200, "Logined Successfully.", values));
    }
    else {
        res.send(responseGenerator.getResponse(500, errorMsg.fieldMissing, []));
    }
}