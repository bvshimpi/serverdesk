var express = require("express");
var api = require('../modules/user/userController');
var router = new express.router();

router.post("/login", api.login);

module.exports = router;