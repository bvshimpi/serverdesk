module.exports = {
    port: 9886,
    databaseHost: 'localhost',
    databaseUser: 'root',
    databasePassword: '',
    databaseDatabaseName: 'serverdesk',
    privateKey: '37LvPsm4vaBcd4CY',
    frontEndHost: "http://localhost:4200",
    emailAccountUserName: 'pavan.winjit@gmail.com',
    emailAccountPassword: 'PavanOffice@1992',
    FromEmail: 'pavan.winjit@gmail.com'
  };
