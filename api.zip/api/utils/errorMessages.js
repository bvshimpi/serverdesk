module.exports = {
    tokenInvalid : 'Failed to authorize',
    dbError : 'Failed to process your request',
    fieldMissing: 'Required Fields are mising in api'
}